package com.poc;
import org.apache.poi.xwpf.usermodel.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class CreateDocument {
    public static void main(String[] args) throws Exception{
        XWPFDocument document= new XWPFDocument();
        FileOutputStream in = new FileOutputStream(new File("createdocument.doc"));
        document.write(in);
        in.close();
        System.out.println("createdocument.doc created successfuly");

    }
}
