package com.poc;

import java.io.*;

public class ReadandWrite {
    public static void main(String[] args) throws Throwable {
//to read
        File infile = new File("resume.docx");
        StringBuffer buffer = new StringBuffer();
        String string = new String();
        BufferedReader reader = new BufferedReader(new InputStreamReader(new
                FileInputStream(infile)));
        while ((string = reader.readLine()) != null) {
            buffer.append(string);
            buffer.append("\n");
            System.out.println(string);
        }
        reader.close();
        //to write
        File outfile = new File("output.doc");
        FileOutputStream fos = new FileOutputStream(outfile);
        DataOutputStream dos = new DataOutputStream(fos);
        dos.writeBytes(buffer.toString());
        dos.close();
        dos.flush();
        fos.close();
    }
}

