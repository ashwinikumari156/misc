package com.poc;

import java.io.FileWriter;

public class TextFileWriting {
    public static void main(String[] args) throws Exception{
        FileWriter writer = new FileWriter("writefile.txt");
        writer.write("Hello World \r\n");
        writer.write("Hello World \n");
        writer.write("\r\n");
        writer.write("Hello World \n");
        writer.write("\r\n");
        writer.write("bye");
        writer.close();
        System.out.println("writefile.txt is created successfully");
    }
}
