package com.poc;

import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class ExtractAndDisplayWordDocument {
    public static void main(String[] args) throws Exception{
        XWPFDocument document = new XWPFDocument(new FileInputStream("resume.docx"));

        //to extract text
        XWPFWordExtractor extractor = new XWPFWordExtractor(document);
        System.out.println(extractor.getText());

        //create new document
        XWPFDocument newdocumet = new XWPFDocument();
        FileOutputStream out = new FileOutputStream(new File("displaydocument1.doc"));
        XWPFParagraph paragraph = newdocumet.createParagraph();
        XWPFRun run= paragraph.createRun();
        run.setText(extractor.getText());
        System.out.println("displaydocument.doc is created successfuly");

    }
}
