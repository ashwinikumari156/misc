package com.poc;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class TextFileUTFEncoding {
    public static void main(String[] args) {
        try{
            FileOutputStream outputStream = new FileOutputStream("utftext.txt");
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream, "UTF-16");
            BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);
            bufferedWriter.write("hey u idiot");
            bufferedWriter.newLine();
            bufferedWriter.write("sry about that");
            bufferedWriter.newLine();
            bufferedWriter.write("Xin chào");
            bufferedWriter.newLine();
            bufferedWriter.write("Hẹn gặp lại!");
            bufferedWriter.close();
            System.out.println("utftext.txt is created successfuly");
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}
