package com.poc;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;

import java.io.File;
import java.io.FileOutputStream;

public class CreateParagraph {
    public static void main(String[] args) throws Exception{
        XWPFDocument document= new XWPFDocument();
        FileOutputStream out = new FileOutputStream(new File("createparagraph.doc"));

        //to create paragraph
        XWPFParagraph paragraph = document.createParagraph();
        XWPFRun run = paragraph.createRun();
        run.setText("  adding paragraph adding paragraph");
        document.write(out);
        out.close();
        System.out.println("createparagraph.doc is created successfuly");

    }
}
