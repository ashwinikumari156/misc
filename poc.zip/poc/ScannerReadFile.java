package com.poc;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ScannerReadFile {
    public static void main(String[] args) {
        File file = new File("createparagraph.doc");
        try {
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                System.out.println(line);
            }
            System.out.println("resumeread file is read successfuly");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
