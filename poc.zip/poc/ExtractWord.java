package com.poc;

import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class ExtractWord {
    public static void main(String[] args) throws Exception{
        XWPFDocument document = new XWPFDocument(new FileInputStream("createparagraph.doc"));

        //to extract text
        XWPFWordExtractor extractor = new XWPFWordExtractor(document);
        System.out.println(extractor.getDocument().toString());
    }
}
