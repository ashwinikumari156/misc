package com.poc;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class TextFileBufferedWriter {
    public static void main(String[] args) {
        try{
            FileWriter file = new FileWriter("bufferedfile.txt");
            BufferedWriter bufwriter= new BufferedWriter(file);
            bufwriter.write("Thos is a buffered file");
            bufwriter.newLine();
            bufwriter.write("Last line");
            bufwriter.newLine();
            bufwriter.write("hi again");
            bufwriter.close();
            System.out.println("bufferedwriter.txt is created successfully");

        }catch(IOException e){
            e.printStackTrace();
        }
    }
}
